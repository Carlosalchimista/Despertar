import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        // Paleta de colores Consciencia con Amor
        'cosmic-purple': {
          '900': '#3D1A4F',
          '800': '#4D2160',
          '700': '#5B2C6F',
          '600': '#7B3F8F',
          '500': '#9B5FB0',
          '400': '#B19CD9',
          '300': '#C5B3E6',
          '200': '#D4C5E8',
          '100': '#E8DFF5',
          '50': '#F8F6F9',
        },
        'cosmic-gold': {
          '600': '#B8860B',
          '500': '#D4AF37',
          '400': '#FFD700',
        },
      },
      backgroundImage: {
        'cosmic-gradient': 'linear-gradient(135deg, #3D1A4F 0%, #5B2C6F 50%, #7B3F8F 100%)',
        'cosmic-gradient-light': 'linear-gradient(135deg, #B19CD9 0%, #D4C5E8 50%, #E8DFF5 100%)',
        'cosmic-radial': 'radial-gradient(circle at 50% 50%, #7B3F8F 0%, #5B2C6F 50%, #3D1A4F 100%)',
      },
      animation: {
        'float': 'float 6s ease-in-out infinite',
        'pulse-slow': 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'shimmer': 'shimmer 2s linear infinite',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-20px)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-1000px 0' },
          '100%': { backgroundPosition: '1000px 0' },
        },
      },
    },
  },
  plugins: [],
};
export default config;