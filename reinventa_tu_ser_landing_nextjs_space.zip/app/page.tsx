import Image from "next/image";
import { 
  Heart, 
  Brain, 
  Sparkles, 
  Check, 
  Star, 
  Lightbulb,
  Target,
  Zap,
  Shield,
  Users,
  MessageCircle,
  Instagram,
  ArrowRight
} from "lucide-react";
import CountdownTimer from "@/components/countdown-timer";
import CTAButton from "@/components/cta-button";
import AnimatedSection from "@/components/animated-section";
import FAQAccordion from "@/components/faq-accordion";

export default function Home() {
  return (
    <main className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0 z-0">
          <Image
            src="https://cdn.abacus.ai/images/d4283472-3c78-42c1-9a91-046857a6fa33.jpg"
            alt="Cosmic spiritual background"
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-b from-cosmic-purple-900/80 via-cosmic-purple-800/70 to-cosmic-purple-900/90" />
        </div>

        {/* Content */}
        <div className="relative z-10 container mx-auto px-4 py-20 text-center">
          {/* Logo */}
          <div className="mb-8 flex justify-center">
            <Image
              src="https://cdn.abacus.ai/images/d92b9fd6-000b-4d3f-b6d5-bc74d2d5ae7c.png"
              alt="Consciencia con Amor Logo"
              width={120}
              height={120}
              className="cosmic-glow-gold"
            />
          </div>

          {/* Countdown */}
          <div className="mb-8 flex justify-center">
            <CountdownTimer />
          </div>

          {/* Headline */}
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight font-[var(--font-cormorant)]">
            ¿Te imaginas cómo sería tu vida si dejaras de sentirte sola… 
            <span className="text-cosmic-gold-400 block mt-2">
              incluso cuando estás contigo misma?
            </span>
          </h1>

          {/* Program Title */}
          <div className="my-8">
            <h2 className="text-5xl md:text-7xl font-bold text-transparent bg-gradient-to-r from-cosmic-purple-300 via-cosmic-purple-200 to-cosmic-gold-400 bg-clip-text mb-4 font-[var(--font-cormorant)] cosmic-glow">
              REINVENTA TU SER
            </h2>
            <p className="text-2xl md:text-3xl text-cosmic-purple-100 font-light">
              Conecta contigo misma para no sentirte sola nunca más
            </p>
          </div>

          {/* Subheadline */}
          <p className="text-xl md:text-2xl text-white/90 max-w-4xl mx-auto mb-10 leading-relaxed">
            Un viaje profundo de <span className="text-cosmic-gold-400 font-semibold">90 días</span> a través del <span className="text-cosmic-gold-400 font-semibold">Método B.P.R.</span> para sanar tu biología, reprogramar tu mente y despertar tu intuición.
          </p>

          {/* CTA */}
          <div className="flex justify-center">
            <CTAButton text="QUIERO EMPEZAR MI TRANSFORMACIÓN" variant="secondary" />
          </div>

          {/* Price */}
          <p className="mt-6 text-3xl font-bold text-cosmic-gold-400 cosmic-glow-gold">
            Solo 47€
          </p>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce">
          <ArrowRight className="w-8 h-8 text-white rotate-90" />
        </div>
      </section>

      {/* Identification Section - Este proceso es para ti si... */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <AnimatedSection>
            <h2 className="text-4xl md:text-5xl font-bold text-center mb-12 text-cosmic-purple-900 font-[var(--font-cormorant)]">
              Este proceso es para ti si…
            </h2>
          </AnimatedSection>

          <div className="grid md:grid-cols-2 gap-6 max-w-5xl mx-auto">
            {[
              "Te sientes sola incluso estando acompañada",
              "Te cuesta poner límites y terminas complaciendo a los demás",
              "Sientes que no eres suficiente",
              "Repites relaciones o situaciones que te drenan",
              "Tu cuerpo expresa lo que no logras decir",
              "Sabes que hay algo más en ti… pero no sabes cómo acceder",
            ]?.map?.((item: string, index: number) => (
              <AnimatedSection key={index} delay={index * 0.1}>
                <div className="flex items-start gap-4 p-6 bg-cosmic-purple-50 rounded-2xl border-2 border-cosmic-purple-200 hover:border-cosmic-purple-400 transition-all hover:shadow-lg">
                  <div className="flex-shrink-0 w-8 h-8 bg-gradient-to-br from-cosmic-purple-600 to-cosmic-purple-500 rounded-full flex items-center justify-center">
                    <Check className="w-5 h-5 text-white" />
                  </div>
                  <p className="text-cosmic-purple-900 text-lg font-medium pt-1">{item}</p>
                </div>
              </AnimatedSection>
            )) ?? null}
          </div>
        </div>
      </section>

      {/* First CTA Section */}
      <section className="py-16 bg-gradient-to-r from-cosmic-purple-700 to-cosmic-purple-600">
        <div className="container mx-auto px-4 text-center">
          <AnimatedSection>
            <h3 className="text-3xl md:text-4xl font-bold text-white mb-6 font-[var(--font-cormorant)]">
              REINVENTA TU SER
            </h3>
            <p className="text-xl text-cosmic-purple-100 mb-8">
              Asegura tu lugar hoy - Solo 47€
            </p>
            <CTAButton text="QUIERO EMPEZAR MI TRANSFORMACIÓN" variant="secondary" />
          </AnimatedSection>
        </div>
      </section>

      {/* Value + Positioning */}
      <section className="py-20 bg-cosmic-purple-50">
        <div className="container mx-auto px-4">
          <AnimatedSection>
            <div className="max-w-4xl mx-auto text-center mb-12">
              <h2 className="text-4xl md:text-5xl font-bold mb-6 text-cosmic-purple-900 font-[var(--font-cormorant)]">
                Esto no es otro curso de motivación.
              </h2>
              <p className="text-xl text-cosmic-purple-700 leading-relaxed">
                Es un proceso estructurado donde vas a trabajar en tres niveles fundamentales de tu ser:
              </p>
            </div>
          </AnimatedSection>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto mb-12">
            {[
              { icon: Heart, title: "Tu cuerpo", subtitle: "(biología)" },
              { icon: Brain, title: "Tu mente", subtitle: "(programación)" },
              { icon: Sparkles, title: "Tu intuición", subtitle: "(conexión interna)" },
            ]?.map?.((item: any, index: number) => {
              const Icon = item?.icon;
              return (
                <AnimatedSection key={index} delay={index * 0.2}>
                  <div className="text-center p-8 bg-white rounded-3xl shadow-xl hover:shadow-2xl transition-all hover:-translate-y-2 border border-cosmic-purple-200">
                    <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-br from-cosmic-purple-600 to-cosmic-purple-500 rounded-full flex items-center justify-center cosmic-glow">
                      <Icon className="w-10 h-10 text-white" />
                    </div>
                    <h3 className="text-2xl font-bold text-cosmic-purple-900 mb-2">
                      {item?.title}
                    </h3>
                    <p className="text-cosmic-purple-600">{item?.subtitle}</p>
                  </div>
                </AnimatedSection>
              );
            }) ?? null}
          </div>

          <AnimatedSection>
            <div className="text-center">
              <p className="text-2xl font-semibold text-cosmic-purple-900 italic">
                Porque no puedes cambiar tu vida… si no cambias lo que la está creando desde dentro.
              </p>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Problem Agitation */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <AnimatedSection>
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-8 text-cosmic-purple-900 font-[var(--font-cormorant)]">
                Durante años has intentado sentirte mejor…
              </h2>
              <p className="text-xl text-cosmic-purple-700 leading-relaxed mb-6">
                leyendo libros, escuchando consejos, intentando “pensar positivo”, adaptándote para ser aceptada.
              </p>
              <p className="text-2xl font-semibold text-cosmic-purple-900 mb-6">
                Pero el vacío vuelve. La soledad vuelve. La inseguridad vuelve.
              </p>
              <p className="text-xl text-cosmic-purple-700 leading-relaxed">
                Porque el problema no está afuera. Está en lo que no has sanado, reprogramado o escuchado dentro de ti.
              </p>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Pattern Break */}
      <section className="py-16 bg-gradient-to-r from-cosmic-gold-500 to-cosmic-gold-400">
        <div className="container mx-auto px-4">
          <AnimatedSection>
            <div className="max-w-4xl mx-auto text-center">
              <h2 className="text-4xl md:text-5xl font-bold mb-6 text-cosmic-purple-900 font-[var(--font-cormorant)]">
                No necesitas hacer más. Necesitas hacer diferente.
              </h2>
              <p className="text-2xl text-cosmic-purple-800">
                No se trata de llenarte de información. Se trata de transformar la raíz de lo que sientes.
              </p>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Personal Story - Teresa */}
      <section className="py-20 bg-cosmic-purple-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <AnimatedSection>
                <div className="relative aspect-[3/4] rounded-3xl overflow-hidden shadow-2xl">
                  <Image
                    src="https://cdn.abacus.ai/images/425a8884-9fcb-4ce3-a0bb-e961bf713f6a.png"
                    alt="Teresa Etlay Luke - Terapeuta Holística"
                    fill
                    className="object-cover"
                  />
                </div>
              </AnimatedSection>

              <AnimatedSection delay={0.3}>
                <div>
                  <h2 className="text-4xl md:text-5xl font-bold mb-6 text-cosmic-purple-900 font-[var(--font-cormorant)]">
                    Yo también me sentí así.
                  </h2>
                  <div className="space-y-4 text-lg text-cosmic-purple-700 leading-relaxed">
                    <p>
                      Hubo un momento en mi vida donde me sentía perdida, insegura… y mi cuerpo empezó a manifestarlo.
                    </p>
                    <p>
                      Me olvidé de mí misma intentando encajar, agradar, sostener todo.
                    </p>
                    <p className="font-semibold text-cosmic-purple-900">
                      Hasta que entendí algo clave: No estaba rota. Estaba desconectada.
                    </p>
                    <p>
                      Y esa desconexión tenía una lógica.
                    </p>
                    <p className="text-xl font-semibold text-cosmic-purple-900">
                      No fue casualidad que cambiara. Fue el resultado de aplicar un método.
                    </p>
                  </div>
                  <div className="mt-8 p-6 bg-white rounded-2xl shadow-lg border-l-4 border-cosmic-purple-600">
                    <p className="font-semibold text-cosmic-purple-900 mb-2">
                      Teresa Etlay Luke
                    </p>
                    <p className="text-cosmic-purple-600">
                      Terapeuta Holística - Consciencia con Amor
                    </p>
                  </div>
                </div>
              </AnimatedSection>
            </div>
          </div>
        </div>
      </section>

      {/* Method Introduction */}
      <section className="py-20 bg-gradient-to-b from-cosmic-purple-900 to-cosmic-purple-800 relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <Image
            src="https://cdn.abacus.ai/images/89807479-26fb-4858-b8ed-6e4b70e3d298.jpg"
            alt="Method visualization"
            fill
            className="object-cover"
          />
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <AnimatedSection>
            <div className="text-center mb-16">
              <h2 className="text-5xl md:text-6xl font-bold mb-6 text-white font-[var(--font-cormorant)]">
                Mi Método B.P.R.
              </h2>
              <p className="text-2xl text-cosmic-purple-200 mb-4">
                La tríada que transformó mi vida
              </p>
              <p className="text-xl text-cosmic-purple-300 max-w-3xl mx-auto">
                No te voy a dar solo consejos. Te voy a enseñar el mismo método que me permitió: sanar mi cuerpo, reprogramar mi mente, despertar mi intuición
              </p>
            </div>
          </AnimatedSection>

          {/* B.P.R. Explanation */}
          <div className="max-w-5xl mx-auto space-y-8">
            {[
              {
                letter: "B",
                title: "Biodecodificación",
                description: "Sanar el cuerpo y liberar el pasado emocional",
                icon: Heart,
              },
              {
                letter: "P",
                title: "Programación Neurolingüística",
                description: "Reprogramar tu mente, tu lenguaje y tu identidad",
                icon: Brain,
              },
              {
                letter: "R",
                title: "Registros e Intuición",
                description: "Conectar con tu sabiduría interior y tu guía profunda",
                icon: Sparkles,
              },
            ]?.map?.((item: any, index: number) => {
              const Icon = item?.icon;
              return (
                <AnimatedSection key={index} delay={index * 0.2}>
                  <div className="bg-white/10 backdrop-blur-sm rounded-3xl p-8 border border-cosmic-purple-400/30 hover:bg-white/15 transition-all hover:shadow-2xl hover:scale-105">
                    <div className="flex items-start gap-6">
                      <div className="flex-shrink-0">
                        <div className="w-20 h-20 bg-gradient-to-br from-cosmic-gold-500 to-cosmic-gold-400 rounded-full flex items-center justify-center text-4xl font-bold text-cosmic-purple-900 cosmic-glow-gold">
                          {item?.letter}
                        </div>
                      </div>
                      <div className="flex-1">
                        <h3 className="text-3xl font-bold text-white mb-3 font-[var(--font-cormorant)]">
                          {item?.title}
                        </h3>
                        <p className="text-xl text-cosmic-purple-200">
                          {item?.description}
                        </p>
                      </div>
                      <div className="flex-shrink-0">
                        <Icon className="w-12 h-12 text-cosmic-gold-400" />
                      </div>
                    </div>
                  </div>
                </AnimatedSection>
              );
            }) ?? null}
          </div>
        </div>
      </section>

      {/* What You'll Experience - 3 Steps */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <AnimatedSection>
            <div className="text-center mb-16">
              <h2 className="text-5xl md:text-6xl font-bold mb-6 text-cosmic-purple-900 font-[var(--font-cormorant)]">
                Qué vivirás dentro
              </h2>
              <p className="text-2xl text-cosmic-purple-700">
                Durante 90 días vas a atravesar un proceso estructurado en 3 etapas:
              </p>
            </div>
          </AnimatedSection>

          {/* Timeline Image */}
          <AnimatedSection>
            <div className="relative aspect-video max-w-5xl mx-auto mb-16 rounded-3xl overflow-hidden shadow-2xl">
              <Image
                src="https://cdn.abacus.ai/images/e888b4dc-f522-4fee-968d-e1870b59443c.jpg"
                alt="90-day transformation journey"
                fill
                className="object-cover"
              />
            </div>
          </AnimatedSection>

          {/* Step 1: Biology */}
          <div className="max-w-5xl mx-auto space-y-16">
            <AnimatedSection>
              <div className="bg-gradient-to-br from-cosmic-purple-600 to-cosmic-purple-700 rounded-3xl p-10 shadow-2xl text-white">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-16 h-16 bg-cosmic-gold-400 rounded-full flex items-center justify-center text-3xl font-bold text-cosmic-purple-900">
                    1
                  </div>
                  <div>
                    <h3 className="text-4xl font-bold font-[var(--font-cormorant)]">
                      BIOLOGÍA – SANAR LA RAÍZ
                    </h3>
                  </div>
                </div>
                
                <p className="text-2xl mb-6 text-cosmic-purple-100">
                  Tu cuerpo no está fallando. Está hablando.
                </p>

                <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 mb-6">
                  <h4 className="text-xl font-semibold mb-4 flex items-center gap-3">
                    <Lightbulb className="w-6 h-6 text-cosmic-gold-400" />
                    Aprenderás a:
                  </h4>
                  <ul className="space-y-3">
                    {[
                      "Identificar el origen emocional de tus bloqueos",
                      "Entender lo que tu cuerpo expresa",
                      "Dejar de adaptarte para ser aceptada",
                    ]?.map?.((item: string, idx: number) => (
                      <li key={idx} className="flex items-start gap-3">
                        <Star className="w-5 h-5 text-cosmic-gold-400 flex-shrink-0 mt-1" />
                        <span className="text-lg">{item}</span>
                      </li>
                    )) ?? null}
                  </ul>
                </div>

                <div className="bg-cosmic-gold-400/20 rounded-2xl p-6">
                  <p className="font-semibold text-lg">
                    <span className="text-cosmic-gold-400">✨ Práctica clave:</span> Mapa de tus silencios
                  </p>
                </div>
              </div>
            </AnimatedSection>

            {/* Step 2: Programming */}
            <AnimatedSection>
              <div className="bg-gradient-to-br from-cosmic-purple-700 to-cosmic-purple-800 rounded-3xl p-10 shadow-2xl text-white">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-16 h-16 bg-cosmic-gold-400 rounded-full flex items-center justify-center text-3xl font-bold text-cosmic-purple-900">
                    2
                  </div>
                  <div>
                    <h3 className="text-4xl font-bold font-[var(--font-cormorant)]">
                      PROGRAMACIÓN – CAMBIAR EL SOFTWARE
                    </h3>
                  </div>
                </div>
                
                <p className="text-2xl mb-6 text-cosmic-purple-100">
                  Tu mente está programada… y puedes reescribirla.
                </p>

                <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 mb-6">
                  <h4 className="text-xl font-semibold mb-4 flex items-center gap-3">
                    <Lightbulb className="w-6 h-6 text-cosmic-gold-400" />
                    Aprenderás a:
                  </h4>
                  <ul className="space-y-3">
                    {[
                      "Cambiar tu diálogo interno",
                      "Eliminar creencias de 'no soy suficiente'",
                      "Construir una nueva identidad",
                    ]?.map?.((item: string, idx: number) => (
                      <li key={idx} className="flex items-start gap-3">
                        <Star className="w-5 h-5 text-cosmic-gold-400 flex-shrink-0 mt-1" />
                        <span className="text-lg">{item}</span>
                      </li>
                    )) ?? null}
                  </ul>
                </div>

                <div className="bg-cosmic-gold-400/20 rounded-2xl p-6">
                  <p className="font-semibold text-lg mb-2">
                    <span className="text-cosmic-gold-400">🛠️ Herramientas:</span>
                  </p>
                  <p className="text-cosmic-purple-100">
                    Afirmaciones conscientes, trabajo con espejo, creación de tu Código de Identidad
                  </p>
                </div>
              </div>
            </AnimatedSection>

            {/* Step 3: Records */}
            <AnimatedSection>
              <div className="bg-gradient-to-br from-cosmic-purple-800 to-cosmic-purple-900 rounded-3xl p-10 shadow-2xl text-white">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-16 h-16 bg-cosmic-gold-400 rounded-full flex items-center justify-center text-3xl font-bold text-cosmic-purple-900">
                    3
                  </div>
                  <div>
                    <h3 className="text-4xl font-bold font-[var(--font-cormorant)]">
                      REGISTROS – DESPERTAR TU INTUICIÓN
                    </h3>
                  </div>
                </div>
                
                <p className="text-2xl mb-6 text-cosmic-purple-100">
                  Tu intuición no está perdida. Está silenciada.
                </p>

                <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 mb-6">
                  <h4 className="text-xl font-semibold mb-4 flex items-center gap-3">
                    <Lightbulb className="w-6 h-6 text-cosmic-gold-400" />
                    Aprenderás a:
                  </h4>
                  <ul className="space-y-3">
                    {[
                      "Elevar tu energía y tu estado interno",
                      "Conectar con tu sabiduría profunda",
                      "Manifestar desde coherencia",
                    ]?.map?.((item: string, idx: number) => (
                      <li key={idx} className="flex items-start gap-3">
                        <Star className="w-5 h-5 text-cosmic-gold-400 flex-shrink-0 mt-1" />
                        <span className="text-lg">{item}</span>
                      </li>
                    )) ?? null}
                  </ul>
                </div>

                <div className="bg-cosmic-gold-400/20 rounded-2xl p-6">
                  <p className="font-semibold text-lg mb-2">
                    <span className="text-cosmic-gold-400">🌟 Prácticas:</span>
                  </p>
                  <p className="text-cosmic-purple-100">
                    Escritura intuitiva, conexión interna, diseño de entorno de alta vibración
                  </p>
                </div>
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Integration - 90 Days Challenge */}
      <section className="py-20 bg-gradient-to-br from-cosmic-purple-100 to-cosmic-purple-200">
        <div className="container mx-auto px-4">
          <AnimatedSection>
            <div className="max-w-4xl mx-auto text-center">
              <div className="relative aspect-video mb-12 rounded-3xl overflow-hidden shadow-2xl">
                <Image
                  src="https://cdn.abacus.ai/images/7f3c9a20-f3d4-4fef-a611-171c04c8b99b.png"
                  alt="Transformation meditation"
                  fill
                  className="object-cover"
                />
              </div>
              
              <h2 className="text-5xl md:text-6xl font-bold mb-6 text-cosmic-purple-900 font-[var(--font-cormorant)]">
                EL RETO DE LOS 90 DÍAS
              </h2>
              <p className="text-2xl text-cosmic-purple-700 mb-6">
                Aquí es donde todo se integra. No es teoría. Es transformación aplicada.
              </p>
              <div className="bg-white rounded-2xl p-8 shadow-xl">
                <p className="text-xl text-cosmic-purple-900 mb-4 font-semibold">
                  Vas a crear:
                </p>
                <ul className="space-y-3 text-lg text-cosmic-purple-700">
                  {[
                    "Nuevos hábitos",
                    "Una nueva relación contigo",
                    "Una nueva forma de vivir",
                  ]?.map?.((item: string, idx: number) => (
                    <li key={idx} className="flex items-center justify-center gap-3">
                      <Zap className="w-6 h-6 text-cosmic-gold-500" />
                      <span>{item}</span>
                    </li>
                  )) ?? null}
                </ul>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <AnimatedSection>
            <div className="text-center mb-16">
              <h2 className="text-5xl md:text-6xl font-bold mb-6 text-cosmic-purple-900 font-[var(--font-cormorant)]">
                Después de este proceso…
              </h2>
            </div>
          </AnimatedSection>

          <div className="max-w-4xl mx-auto space-y-6">
            {[
              { icon: Heart, text: "Dejarás de sentirte sola contigo misma" },
              { icon: Target, text: "Tendrás claridad interna" },
              { icon: Sparkles, text: "Confiarás en tu intuición" },
              { icon: Shield, text: "Dejarás de adaptarte para ser aceptada" },
              { icon: Star, text: "Empezarás a vivir desde tu verdad" },
            ]?.map?.((item: any, index: number) => {
              const Icon = item?.icon;
              return (
                <AnimatedSection key={index} delay={index * 0.1}>
                  <div className="flex items-center gap-6 p-6 bg-gradient-to-r from-cosmic-purple-50 to-cosmic-purple-100 rounded-2xl border-2 border-cosmic-purple-300 hover:border-cosmic-purple-500 transition-all hover:shadow-xl hover:scale-105">
                    <div className="flex-shrink-0 w-16 h-16 bg-gradient-to-br from-cosmic-purple-600 to-cosmic-purple-500 rounded-full flex items-center justify-center">
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    <p className="text-2xl font-semibold text-cosmic-purple-900">
                      {item?.text}
                    </p>
                  </div>
                </AnimatedSection>
              );
            }) ?? null}
          </div>
        </div>
      </section>

      {/* Second CTA */}
      <section className="py-20 bg-gradient-to-br from-cosmic-purple-700 via-cosmic-purple-600 to-cosmic-purple-800">
        <div className="container mx-auto px-4 text-center">
          <AnimatedSection>
            <h2 className="text-5xl md:text-6xl font-bold text-white mb-6 font-[var(--font-cormorant)]">
              REINVENTA TU SER
            </h2>
            <p className="text-2xl text-cosmic-purple-100 mb-4">
              Empieza hoy tu proceso de transformación
            </p>
            <p className="text-4xl font-bold text-cosmic-gold-400 mb-10 cosmic-glow-gold">
              Solo 47€
            </p>
            <CTAButton text="QUIERO EMPEZAR AHORA" variant="secondary" />
          </AnimatedSection>
        </div>
      </section>

      {/* FAQ - Objections */}
      <section className="py-20 bg-cosmic-purple-50">
        <div className="container mx-auto px-4">
          <AnimatedSection>
            <div className="text-center mb-12">
              <h2 className="text-4xl md:text-5xl font-bold mb-4 text-cosmic-purple-900 font-[var(--font-cormorant)]">
                Preguntas Frecuentes
              </h2>
            </div>
          </AnimatedSection>

          <AnimatedSection delay={0.2}>
            <FAQAccordion />
          </AnimatedSection>
        </div>
      </section>

      {/* Emotional Close */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <AnimatedSection>
            <div className="max-w-3xl mx-auto text-center">
              <p className="text-3xl md:text-4xl font-semibold text-cosmic-purple-900 leading-relaxed italic font-[var(--font-cormorant)]">
                La soledad que sientes… no es porque estés sola.
              </p>
              <p className="text-3xl md:text-4xl font-semibold text-cosmic-purple-900 leading-relaxed italic mt-4 font-[var(--font-cormorant)]">
                Es porque no estás completamente contigo.
              </p>
              <p className="text-4xl font-bold text-cosmic-gold-500 mt-8">
                Y eso… se puede transformar.
              </p>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 bg-gradient-to-r from-cosmic-gold-500 to-cosmic-gold-400">
        <div className="container mx-auto px-4 text-center">
          <AnimatedSection>
            <p className="text-2xl md:text-3xl text-cosmic-purple-900 mb-8 font-semibold">
              Este puede ser el inicio de tu nueva relación contigo misma.
            </p>
            <CTAButton text="QUIERO REINVENTARME" variant="primary" />
          </AnimatedSection>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-cosmic-purple-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            {/* Logo */}
            <div className="mb-6 flex justify-center">
              <Image
                src="https://cdn.abacus.ai/images/d92b9fd6-000b-4d3f-b6d5-bc74d2d5ae7c.png"
                alt="Consciencia con Amor Logo"
                width={80}
                height={80}
              />
            </div>

            <h3 className="text-2xl font-bold mb-2 font-[var(--font-cormorant)]">
              Consciencia con Amor
            </h3>
            <p className="text-cosmic-purple-300 mb-6">
              Teresa Etlay Luke - Terapeuta Holística
            </p>

            {/* Instagram */}
            <a
              href="https://www.instagram.com/consciencia_con_amor"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-cosmic-gold-400 hover:text-cosmic-gold-300 transition-colors mb-8"
            >
              <Instagram className="w-6 h-6" />
              @consciencia_con_amor
            </a>

            {/* Disclaimer */}
            <div className="border-t border-cosmic-purple-700 pt-8 mt-8">
              <p className="text-sm text-cosmic-purple-400 leading-relaxed">
                <strong>Disclaimer:</strong> Este proceso es educativo y no sustituye acompañamiento médico o psicológico. Los resultados dependen del compromiso personal con el proceso.
              </p>
            </div>

            <p className="text-cosmic-purple-500 text-sm mt-6">
              © {new Date()?.getFullYear?.()} Consciencia con Amor. Todos los derechos reservados.
            </p>
          </div>
        </div>
      </footer>
    </main>
  );
}