import type { Metadata } from "next";
import { Inter, Cormorant_Garamond } from "next/font/google";
import "./globals.css";

export const dynamic = "force-dynamic";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });
const cormorant = Cormorant_Garamond({ 
  weight: ["300", "400", "600", "700"],
  subsets: ["latin"], 
  variable: "--font-cormorant" 
});

const baseUrl = process.env.NEXTAUTH_URL || 'https://reinventa-tu-ser.abacus.ai';

export const metadata: Metadata = {
  metadataBase: new URL(baseUrl),
  title: "REINVENTA TU SER - Consciencia con Amor | Transformación Personal en 90 Días",
  description: "Conecta contigo misma para no sentirte sola nunca más. Un viaje profundo de 90 días a través del Método B.P.R. para sanar tu biología, reprogramar tu mente y despertar tu intuición.",
  keywords: "transformación personal, biodecodificación, PNL, desarrollo personal, autoconocimiento, consciencia, espiritualidad, Teresa Etlay Luke, terapia holística",
  authors: [{ name: "Teresa Etlay Luke - Consciencia con Amor" }],
  openGraph: {
    type: "website",
    locale: "es_ES",
    url: baseUrl,
    title: "REINVENTA TU SER - Transformación Personal en 90 Días",
    description: "Conecta contigo misma para no sentirte sola nunca más. Método B.P.R.: Biodecodificación, PNL y Registros Intuitivos.",
    siteName: "Consciencia con Amor",
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: "REINVENTA TU SER - Consciencia con Amor",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "REINVENTA TU SER - Transformación Personal en 90 Días",
    description: "Conecta contigo misma para no sentirte sola nunca más. Método B.P.R. con Teresa Etlay Luke.",
    images: ["/og-image.png"],
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es" className={`${inter.variable} ${cormorant.variable}`}>
      <head>
        <script src="https://apps.abacus.ai/chatllm/appllm-lib.js"></script>
      </head>
      <body className={inter.className}>
        {children}
      </body>
    </html>
  );
}