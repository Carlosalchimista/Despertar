"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown } from "lucide-react";

interface FAQItem {
  question: string;
  answer: string;
}

const faqData: FAQItem[] = [
  {
    question: "¿Y si ya he probado muchas cosas?",
    answer: "Entonces sabes que seguir igual no funciona. Aquí no harás más… harás diferente.",
  },
  {
    question: "¿Necesito experiencia previa?",
    answer: "No. Solo apertura y compromiso contigo.",
  },
  {
    question: "¿Esto es espiritual o técnico?",
    answer: "Es ambos. Porque tú eres ambos.",
  },
];

export default function FAQAccordion() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggleAccordion = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="space-y-4 max-w-3xl mx-auto">
      {faqData?.map?.((item: FAQItem, index: number) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          className="bg-white rounded-2xl shadow-lg overflow-hidden border border-cosmic-purple-200 hover:border-cosmic-purple-400 transition-colors"
        >
          <button
            onClick={() => toggleAccordion(index)}
            className="w-full px-6 py-5 flex items-center justify-between text-left hover:bg-cosmic-purple-50 transition-colors"
          >
            <span className="font-semibold text-cosmic-purple-900 text-lg">
              {item?.question}
            </span>
            <motion.div
              animate={{ rotate: openIndex === index ? 180 : 0 }}
              transition={{ duration: 0.3 }}
            >
              <ChevronDown className="w-6 h-6 text-cosmic-purple-600" />
            </motion.div>
          </button>
          <AnimatePresence>
            {openIndex === index && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden"
              >
                <div className="px-6 pb-5 pt-2 text-cosmic-purple-700">
                  {item?.answer}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      )) ?? null}
    </div>
  );
}