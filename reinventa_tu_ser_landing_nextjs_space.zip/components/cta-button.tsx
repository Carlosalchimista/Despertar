"use client";

import { motion } from "framer-motion";
import { MessageCircle, Sparkles } from "lucide-react";
import { useState } from "react";

interface CTAButtonProps {
  text: string;
  variant?: "primary" | "secondary" | "outline";
  icon?: boolean;
  className?: string;
}

export default function CTAButton({ text, variant = "primary", icon = true, className = "" }: CTAButtonProps) {
  const [isHovered, setIsHovered] = useState(false);
  
  // Número de WhatsApp placeholder - se puede configurar fácilmente
  const whatsappNumber = "+34600000000"; // PLACEHOLDER - configurar con número real
  const message = encodeURIComponent(
    `Hola Teresa, me interesa el programa REINVENTA TU SER. Me gustaría obtener más información sobre el proceso de transformación de 90 días. 🌟`
  );
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${message}`;

  const handleClick = () => {
    window?.open?.(whatsappUrl, "_blank");
  };

  const baseStyles = "relative overflow-hidden rounded-full font-semibold transition-all duration-300 transform hover:scale-105 active:scale-95 flex items-center justify-center gap-3 px-8 py-4 text-lg shadow-lg";
  
  const variants = {
    primary: "bg-gradient-to-r from-cosmic-purple-700 to-cosmic-purple-600 text-white hover:from-cosmic-purple-600 hover:to-cosmic-purple-500 cosmic-glow hover:cosmic-glow-gold",
    secondary: "bg-gradient-to-r from-cosmic-gold-500 to-cosmic-gold-400 text-cosmic-purple-900 hover:from-cosmic-gold-400 hover:to-cosmic-gold-500 cosmic-glow-gold",
    outline: "border-2 border-cosmic-purple-600 text-cosmic-purple-700 hover:bg-cosmic-purple-600 hover:text-white",
  };

  return (
    <motion.button
      onClick={handleClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className={`${baseStyles} ${variants[variant]} ${className}`}
    >
      {icon && (
        <motion.div
          animate={{ rotate: isHovered ? 360 : 0 }}
          transition={{ duration: 0.5 }}
        >
          {variant === "primary" || variant === "secondary" ? (
            <MessageCircle className="w-6 h-6" />
          ) : (
            <Sparkles className="w-6 h-6" />
          )}
        </motion.div>
      )}
      <span className="relative z-10">{text}</span>
      <motion.div
        className="absolute inset-0 bg-white opacity-0 hover:opacity-20"
        animate={{ opacity: isHovered ? 0.2 : 0 }}
        transition={{ duration: 0.3 }}
      />
    </motion.button>
  );
}