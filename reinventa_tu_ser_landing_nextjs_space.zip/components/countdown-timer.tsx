"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Clock } from "lucide-react";

export default function CountdownTimer() {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return (
      <div className="flex items-center justify-center gap-2 py-3 px-6 bg-cosmic-purple-800/30 rounded-full backdrop-blur-sm border border-cosmic-purple-400/30">
        <Clock className="w-5 h-5 text-cosmic-gold-400" />
        <span className="text-white font-medium">Cargando...</span>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="flex items-center justify-center gap-2 py-3 px-6 bg-cosmic-purple-800/30 rounded-full backdrop-blur-sm border border-cosmic-purple-400/30 cosmic-glow"
    >
      <Clock className="w-5 h-5 text-cosmic-gold-400 animate-pulse" />
      <span className="text-white font-medium">Próximamente</span>
    </motion.div>
  );
}